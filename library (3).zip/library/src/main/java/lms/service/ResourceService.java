package lms.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import lms.entity.Resource;
import lms.repository.ResourceRepository;

@Service
public class ResourceService {

	@Autowired
	private ResourceRepository resourceRepository;

	public List<Resource> getAllresourcesById(String categoryId)
	{
		List<Resource> resources=new ArrayList<>();
		resourceRepository.findByCategoryId(categoryId)
		.forEach(resources::add);
		return resources;
	}
	
	public List<Resource> getAllgenreById(String genreId)
	{
		List<Resource> genres=new ArrayList<>();
		resourceRepository.findByGenreId(genreId)
		.forEach(genres::add);
		return genres;
	}

	public Resource getResource(String categoryId) 
	{
		return resourceRepository.findOne(categoryId);
	}
	
	public Resource getGenre(String genreId) 
	{
		return resourceRepository.findOne(genreId);
	}
	

	public void addResource(Resource resource)
	{
		resourceRepository.save(resource);
	}

	public void updateResource(Resource resource)
	{
		resourceRepository.save(resource);
	}

	public void deleteResource(String id) 
	{
		resourceRepository.delete(id);
	}

	


}
