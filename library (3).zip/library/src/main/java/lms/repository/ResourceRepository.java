package lms.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import lms.entity.Resource;

public interface ResourceRepository extends CrudRepository<Resource, String>{
	
	public List<Resource> findByCategoryId(String categoryId);
	public List<Resource> findByGenreId(String genreId);
	

}
